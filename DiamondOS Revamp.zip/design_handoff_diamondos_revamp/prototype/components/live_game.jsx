// Live Game scoring page — the hero screen
const { useState: lgUseState, useEffect: lgUseEffect, useRef: lgUseRef } = React;

function LiveGamePage({ tone }) {
  // Game state
  const [balls, setBalls]     = lgUseState(2);
  const [strikes, setStrikes] = lgUseState(1);
  const [outs, setOuts]       = lgUseState(1);
  const [inning, setInning]   = lgUseState({ num: 4, half: "top" });
  const [score, setScore]     = lgUseState({ home: 4, away: 2 });
  const [runners, setRunners] = lgUseState({ first: true, second: true, third: false });
  const [pinged, setPinged]   = lgUseState(null);
  const [lastEvent, setLastEvent] = lgUseState("Foul ball — Rivera fouls off a 2-1 slider to stay alive");
  const [history, setHistory] = lgUseState([
    { t: "T4 · 0 out", txt: "#14 Chen — Single to RF",    type:"hit" },
    { t: "T4 · 0 out", txt: "#22 Reyes — Walk (4 pitches)", type:"walk" },
    { t: "T4 · 1 out", txt: "#7 Patel — Flyout to CF",     type:"out" },
    { t: "T4 · 1 out", txt: "#9 Rivera — At bat",          type:"ab" },
  ]);
  const [pitches, setPitches] = lgUseState([
    { x: 0.55, y: 0.60, call: "ball",    num: 1 },
    { x: 0.48, y: 0.42, call: "strike",  num: 2 },
    { x: 0.72, y: 0.30, call: "ball",    num: 3 },
    { x: 0.40, y: 0.55, call: "foul",    num: 4 },
  ]);

  // "At bat" batter info
  const batter = { num: 9, name: "M. Rivera", pos: "CF", line: "2-for-3, RBI, SB" };
  const pitcher = { num: 21, name: "T. Kowalski", line: "3.1 IP, 4 H, 2 ER, 54 P" };

  const ping = (k) => { setPinged(k); setTimeout(()=>setPinged(null), 480); };

  const onPitch = (type) => {
    if (type === "ball") {
      if (balls >= 3) {
        setLastEvent(`Ball 4 — ${batter.name} walks`);
        walkRunners();
        resetCount();
      } else {
        setBalls(balls+1); ping("b");
        setLastEvent("Ball — outside");
      }
    } else if (type === "calledK" || type === "swingK") {
      if (strikes >= 2) {
        setLastEvent(`Strike 3 — ${batter.name} ${type==="calledK"?"looking":"swinging"}`);
        addOut(); resetCount();
      } else {
        setStrikes(strikes+1); ping("s");
        setLastEvent(`Strike — ${type==="calledK"?"called":"swinging"}`);
      }
    } else if (type === "foul") {
      if (strikes < 2) { setStrikes(strikes+1); ping("s"); }
      setLastEvent("Foul ball");
    } else if (type === "inPlay") {
      setLastEvent("In play — awaiting result");
    }
    // push pitch to heatmap (random within zone)
    setPitches(p => [...p, { x: 0.3 + Math.random()*0.4, y: 0.25 + Math.random()*0.55, call: type, num: p.length+1 }]);
  };

  const walkRunners = () => {
    setRunners(r => {
      let nr = {...r};
      if (r.first && r.second && r.third) setScore(s => ({...s, away: s.away+1}));
      if (r.first && r.second) nr.third = true;
      if (r.first) nr.second = true;
      nr.first = true;
      return nr;
    });
  };
  const resetCount = () => { setBalls(0); setStrikes(0); };
  const addOut = () => {
    if (outs >= 2) { setOuts(0); setInning(i => ({ num: i.half==="bot"?i.num+1:i.num, half: i.half==="top"?"bot":"top" })); setRunners({first:false,second:false,third:false}); }
    else { setOuts(outs+1); ping("o"); }
  };

  const onResult = (res) => {
    if (res==="out") { setLastEvent(`${batter.name} — Groundout`); addOut(); resetCount(); }
    else if (res==="1B") { setLastEvent(`${batter.name} — Single to left`); advance(1); resetCount(); }
    else if (res==="2B") { setLastEvent(`${batter.name} — Double down the line`); advance(2); resetCount(); }
    else if (res==="3B") { setLastEvent(`${batter.name} — Triple!`); advance(3); resetCount(); }
    else if (res==="HR") { setLastEvent(`${batter.name} — HOME RUN`); homeRun(); resetCount(); }
    else if (res==="err"){ setLastEvent("Reached on error"); advance(1); resetCount(); }
  };
  const advance = (bases) => {
    setRunners(r => {
      let runs = 0;
      let n = { first: false, second: false, third: false };
      const allRunners = [r.first, r.second, r.third]; // positions 1,2,3
      // Move existing runners
      allRunners.forEach((occ, idx) => {
        if (!occ) return;
        const newPos = idx+1+bases;
        if (newPos >= 4) runs++;
        else if (newPos === 1) n.first  = true;
        else if (newPos === 2) n.second = true;
        else if (newPos === 3) n.third  = true;
      });
      // Batter
      if (bases >= 4) runs++;
      else if (bases === 1) n.first  = true;
      else if (bases === 2) n.second = true;
      else if (bases === 3) n.third  = true;
      if (runs) setScore(s => ({...s, away: s.away + runs}));
      return n;
    });
  };
  const homeRun = () => {
    let runs = 1 + (runners.first?1:0) + (runners.second?1:0) + (runners.third?1:0);
    setRunners({first:false, second:false, third:false});
    setScore(s => ({...s, away: s.away + runs}));
  };

  return (
    <div className="page" style={{maxWidth: 1400, paddingTop: 0, paddingLeft: 20, paddingRight: 20}}>
      {/* Scoreboard hero */}
      <div className="card card-hero" style={{marginTop: 20, padding: 24, borderRadius: 18}}>
        <div className="between" style={{alignItems:"flex-start"}}>
          <div>
            <div className="eyebrow" style={{color:"var(--turf-200)"}}>
              <span className="live-chip" style={{background:"#dc2626", marginRight:8}}><span className="pulse"/>Live</span>
              {inning.half==="top"?"Top":"Bot"} of {inning.num}
            </div>
            <div className="display" style={{fontSize:46, marginTop:8, color:"white"}}>
              Wildcats <span style={{opacity:.55, fontFamily:"var(--font-sans)", fontWeight:500, fontSize:24}}>vs</span> Hawks
            </div>
            <div className="muted" style={{color:"rgba(255,255,255,.7)", marginTop: 4, fontSize: 13}}>
              Ridgeview HS · Field 2 · Sat 3:30 PM
            </div>
          </div>
          <div className="flex" style={{gap: 28, alignItems:"center"}}>
            <div style={{textAlign:"center"}}>
              <div style={{fontSize:11, color:"rgba(255,255,255,.6)", letterSpacing:".1em", textTransform:"uppercase"}}>Away</div>
              <div className="mono" style={{fontSize: 64, fontWeight:800, lineHeight:1, color:"white", fontFamily:"var(--font-display)"}}>{score.away}</div>
              <div style={{fontSize:12, color:"rgba(255,255,255,.75)", marginTop:4}}>Wildcats</div>
            </div>
            <div style={{color:"rgba(255,255,255,.3)", fontSize:24, fontFamily:"var(--font-display)", fontStyle:"italic"}}>vs</div>
            <div style={{textAlign:"center"}}>
              <div style={{fontSize:11, color:"rgba(255,255,255,.6)", letterSpacing:".1em", textTransform:"uppercase"}}>Home</div>
              <div className="mono" style={{fontSize: 64, fontWeight:800, lineHeight:1, color:"white", fontFamily:"var(--font-display)"}}>{score.home}</div>
              <div style={{fontSize:12, color:"rgba(255,255,255,.75)", marginTop:4}}>Hawks</div>
            </div>
          </div>
        </div>

        {/* Inning grid */}
        <div style={{marginTop: 22, display:"grid", gridTemplateColumns:"80px repeat(9, 1fr) 50px 50px 50px", gap:0, fontSize:12, color:"rgba(255,255,255,.8)"}}>
          <div style={{fontWeight:700, padding:"8px 4px"}}>Team</div>
          {[1,2,3,4,5,6,7,8,9].map(i => (
            <div key={i} style={{textAlign:"center", padding:"8px 4px", fontWeight: i===inning.num?800:500, color: i===inning.num?"var(--turf-200)":"rgba(255,255,255,.6)"}}>{i}</div>
          ))}
          <div style={{textAlign:"center", padding:"8px 4px", fontWeight:700}}>R</div>
          <div style={{textAlign:"center", padding:"8px 4px", fontWeight:700}}>H</div>
          <div style={{textAlign:"center", padding:"8px 4px", fontWeight:700}}>E</div>

          <div style={{padding:"8px 4px", fontWeight:700, borderTop:"1px solid rgba(255,255,255,.1)"}}>WLD</div>
          {["0","1","1","—","","","","","",].map((v,i) => (
            <div key={i} className="mono" style={{textAlign:"center", padding:"8px 4px", borderTop:"1px solid rgba(255,255,255,.1)", color: v==="—"?"var(--turf-200)":"white", fontWeight: v==="—"?800:400}}>
              {i===3 ? score.away : v}
            </div>
          ))}
          <div className="mono" style={{textAlign:"center", padding:"8px 4px", borderTop:"1px solid rgba(255,255,255,.1)", fontWeight:800}}>{score.away}</div>
          <div className="mono" style={{textAlign:"center", padding:"8px 4px", borderTop:"1px solid rgba(255,255,255,.1)"}}>5</div>
          <div className="mono" style={{textAlign:"center", padding:"8px 4px", borderTop:"1px solid rgba(255,255,255,.1)"}}>1</div>

          <div style={{padding:"8px 4px", fontWeight:700, borderTop:"1px solid rgba(255,255,255,.08)"}}>HAW</div>
          {["2","0","0","","","","","","",].map((v,i) => (
            <div key={i} className="mono" style={{textAlign:"center", padding:"8px 4px", borderTop:"1px solid rgba(255,255,255,.08)"}}>{v}</div>
          ))}
          <div className="mono" style={{textAlign:"center", padding:"8px 4px", borderTop:"1px solid rgba(255,255,255,.08)", fontWeight:800}}>{score.home}</div>
          <div className="mono" style={{textAlign:"center", padding:"8px 4px", borderTop:"1px solid rgba(255,255,255,.08)"}}>3</div>
          <div className="mono" style={{textAlign:"center", padding:"8px 4px", borderTop:"1px solid rgba(255,255,255,.08)"}}>0</div>
        </div>
      </div>

      {/* Main scoring grid */}
      <div style={{display:"grid", gridTemplateColumns: "1fr 1.1fr 1fr", gap: 16, marginTop: 16}}>
        {/* LEFT: Diamond + runners + at bat */}
        <div className="card" style={{padding: 20}}>
          <div className="eyebrow">Field</div>
          <div style={{display:"flex", justifyContent:"center", marginTop: 6}}>
            <DiamondField runners={runners} size={240} variant={tone}/>
          </div>
          <div style={{marginTop: 10, fontSize: 12, color:"var(--app-fg-muted)", textAlign:"center"}}>
            {[runners.first && "1st", runners.second && "2nd", runners.third && "3rd"].filter(Boolean).join(" · ") || "Bases empty"}
          </div>

          <div style={{marginTop: 16, paddingTop: 16, borderTop:"1px solid var(--app-border)"}}>
            <div className="between">
              <div>
                <div className="eyebrow">At bat</div>
                <div style={{display:"flex", alignItems:"center", gap:10, marginTop:6}}>
                  <div className="avatar" style={{background:"linear-gradient(135deg,var(--brand-500),var(--brand-800))"}}>{batter.num}</div>
                  <div>
                    <div style={{fontWeight: 700, fontSize: 15}}>{batter.name}</div>
                    <div style={{fontSize: 11, color:"var(--app-fg-muted)"}}>{batter.pos} · {batter.line}</div>
                  </div>
                </div>
              </div>
            </div>
            <div style={{marginTop: 12, display:"flex", justifyContent:"space-between", alignItems:"center"}}>
              <div>
                <div className="eyebrow">Pitching</div>
                <div style={{fontSize:13, fontWeight:600, marginTop:4}}>#{pitcher.num} {pitcher.name}</div>
                <div style={{fontSize:11, color:"var(--app-fg-muted)"}}>{pitcher.line}</div>
              </div>
              <div style={{textAlign:"right"}}>
                <div className="eyebrow">Pitch count</div>
                <div className="mono" style={{fontWeight:700, fontSize:20, color: "var(--warning)"}}>54 <span style={{fontSize:12, color:"var(--app-fg-muted)", fontWeight: 500}}>/ 85</span></div>
                <div style={{marginTop: 4, width: 100, height: 5, background:"var(--app-surface-2)", borderRadius: 999, overflow:"hidden", marginLeft:"auto"}}>
                  <div style={{width: "64%", height:"100%", background:"var(--warning)", transition:"width 400ms var(--ease)"}}/>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CENTER: Pitch/play inputs */}
        <div className="card" style={{padding: 20, display:"flex", flexDirection:"column"}}>
          <div className="between">
            <div className="eyebrow">Count</div>
            <button className="btn btn-sm btn-ghost"><Ico.undo/> Undo</button>
          </div>
          <div style={{marginTop: 10}}>
            <CountDots balls={balls} strikes={strikes} outs={outs} pinged={pinged}/>
          </div>

          <div className="eyebrow" style={{marginTop: 18}}>Record pitch</div>
          <div className="grid g-3" style={{marginTop: 8, gap: 8}}>
            <PitchBtn label="Ball"     hot="B" tone="ball"   onClick={() => onPitch("ball")}/>
            <PitchBtn label="Called K" hot="C" tone="calledK" onClick={() => onPitch("calledK")}/>
            <PitchBtn label="Swing K"  hot="S" tone="swingK" onClick={() => onPitch("swingK")}/>
            <PitchBtn label="Foul"     hot="F" tone="foul"   onClick={() => onPitch("foul")}/>
            <PitchBtn label="In Play"  hot="P" tone="inPlay" onClick={() => onPitch("inPlay")} wide/>
          </div>

          <div className="eyebrow" style={{marginTop: 18}}>What happened?</div>
          <div className="grid g-3" style={{marginTop: 8, gap: 8}}>
            <PitchBtn label="Out"       tone="out" onClick={() => onResult("out")}/>
            <PitchBtn label="Single"    tone="1B"  onClick={() => onResult("1B")}/>
            <PitchBtn label="Double"    tone="2B"  onClick={() => onResult("2B")}/>
            <PitchBtn label="Triple"    tone="3B"  onClick={() => onResult("3B")}/>
            <PitchBtn label="Home Run"  tone="HR"  onClick={() => onResult("HR")}/>
            <PitchBtn label="Error"     tone="err" onClick={() => onResult("err")}/>
          </div>

          {/* Last event ticker */}
          <div style={{marginTop: "auto", paddingTop: 16, borderTop:"1px solid var(--app-border)"}}>
            <div className="eyebrow">Last event</div>
            <div key={lastEvent} style={{
              marginTop: 6,
              padding: "10px 12px",
              background: "var(--brand-50, #eff6ff)",
              border: "1px solid var(--brand-100)",
              color: "var(--brand-700)",
              borderRadius: 10,
              fontWeight: 600, fontSize: 13,
              animation: "fadeUp 320ms var(--ease)"
            }}>
              {lastEvent}
            </div>
          </div>
        </div>

        {/* RIGHT: Strike zone heatmap + play log */}
        <div style={{display:"flex", flexDirection:"column", gap: 16}}>
          <div className="card" style={{padding: 20}}>
            <div className="between">
              <div className="eyebrow">This at-bat</div>
              <span className="badge badge-info">{pitches.length} pitches</span>
            </div>
            <div style={{display:"flex", justifyContent:"center", marginTop: 12}}>
              <StrikeZoneHeatmap pitches={pitches}/>
            </div>
          </div>
          <div className="card" style={{padding: 16, flex:1, minHeight: 0, display:"flex", flexDirection:"column"}}>
            <div className="eyebrow">Play log</div>
            <div style={{marginTop: 8, display:"flex", flexDirection:"column", gap: 8, overflow:"auto", flex: 1, maxHeight: 220}}>
              {history.slice().reverse().map((h, i) => (
                <div key={i} style={{display:"flex", gap:10, alignItems:"flex-start", fontSize:12}}>
                  <div style={{
                    width: 6, minWidth: 6, height: 6, borderRadius: "50%", marginTop: 6,
                    background: h.type==="hit"?"var(--turf-500)": h.type==="out"?"var(--count-outs)": h.type==="walk"?"var(--count-balls)": "var(--brand-500)"
                  }}/>
                  <div style={{flex:1}}>
                    <div style={{fontWeight: 600}}>{h.txt}</div>
                    <div className="mono" style={{fontSize: 10, color:"var(--app-fg-subtle)"}}>{h.t}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PitchBtn({ label, tone, hot, onClick, wide }) {
  const toneMap = {
    ball:    { bg:"var(--green-50)",  fg:"var(--green-700)",  bd:"var(--green-200)"  },
    calledK: { bg:"var(--yellow-50)", fg:"var(--yellow-700)", bd:"var(--yellow-200)" },
    swingK:  { bg:"var(--orange-50)", fg:"var(--orange-700)", bd:"var(--orange-200)" },
    foul:    { bg:"var(--gray-100)",  fg:"var(--gray-700)",   bd:"var(--gray-300)"   },
    inPlay:  { bg:"var(--blue-50)",   fg:"var(--blue-700)",   bd:"var(--blue-200)"   },
    out:     { bg:"var(--red-50)",    fg:"var(--red-700)",    bd:"var(--red-200)"    },
    "1B":    { bg:"var(--green-50)",  fg:"var(--green-700)",  bd:"var(--green-200)"  },
    "2B":    { bg:"var(--blue-50)",   fg:"var(--blue-700)",   bd:"var(--blue-200)"   },
    "3B":    { bg:"var(--purple-50)", fg:"var(--purple-700)", bd:"var(--purple-200)" },
    HR:      { bg:"var(--yellow-50)", fg:"var(--yellow-700)", bd:"var(--yellow-200)" },
    err:     { bg:"var(--gray-100)",  fg:"var(--gray-700)",   bd:"var(--gray-300)"   },
  };
  const t = toneMap[tone] || toneMap.foul;
  return (
    <button
      onClick={onClick}
      style={{
        gridColumn: wide ? "span 3" : undefined,
        padding: "14px 10px",
        background: t.bg, color: t.fg,
        border: `1.5px solid ${t.bd}`,
        borderRadius: 12,
        fontWeight: 700, fontSize: 14,
        display:"flex", alignItems:"center", justifyContent:"center", gap: 8,
        transition:"transform 150ms var(--ease), box-shadow 150ms var(--ease), filter 150ms var(--ease)",
      }}
      onMouseDown={(e)=>{ e.currentTarget.style.transform="scale(.97)"; }}
      onMouseUp={(e)=>{ e.currentTarget.style.transform=""; }}
      onMouseLeave={(e)=>{ e.currentTarget.style.transform=""; }}
    >
      {label}
      {hot && <kbd style={{background:"rgba(255,255,255,.6)", border:"none", color:t.fg, opacity:.6}}>{hot}</kbd>}
    </button>
  );
}

// Strike zone with pitch markers
function StrikeZoneHeatmap({ pitches }) {
  const w = 200, h = 260;
  const zoneX = 40, zoneY = 40, zoneW = 120, zoneH = 160;
  const callColor = {
    ball:    "var(--count-balls)",
    calledK: "var(--count-strikes)",
    swingK:  "var(--clay-500)",
    foul:    "var(--gray-500)",
    inPlay:  "var(--brand-500)",
  };
  return (
    <svg width={w} height={h} style={{display:"block"}}>
      {/* Backstop region */}
      <rect x="10" y="10" width={w-20} height={h-30} fill="var(--app-surface-2)" stroke="var(--app-border)" rx="6"/>
      {/* Zone */}
      <rect x={zoneX} y={zoneY} width={zoneW} height={zoneH} fill="var(--app-surface)" stroke="var(--app-border-strong)" strokeWidth="2"/>
      {/* Gridlines */}
      {[1,2].map(i => (
        <React.Fragment key={i}>
          <line x1={zoneX+zoneW*i/3} x2={zoneX+zoneW*i/3} y1={zoneY} y2={zoneY+zoneH} stroke="var(--app-border)" strokeDasharray="2 3"/>
          <line x1={zoneX} x2={zoneX+zoneW} y1={zoneY+zoneH*i/3} y2={zoneY+zoneH*i/3} stroke="var(--app-border)" strokeDasharray="2 3"/>
        </React.Fragment>
      ))}
      {/* Plate */}
      <polygon points={`${w/2-30},${h-15} ${w/2+30},${h-15} ${w/2+30},${h-22} ${w/2},${h-30} ${w/2-30},${h-22}`} fill="white" stroke="var(--app-border-strong)"/>

      {/* Pitch dots */}
      {pitches.map((p, i) => {
        const cx = zoneX + p.x * zoneW;
        const cy = zoneY + p.y * zoneH;
        const color = callColor[p.call] || "var(--gray-500)";
        return (
          <g key={i}>
            <circle cx={cx} cy={cy} r="10" fill={color} opacity="0.18"/>
            <circle cx={cx} cy={cy} r="6" fill={color} stroke="white" strokeWidth="1.5"/>
            <text x={cx} y={cy+3} textAnchor="middle" fontSize="9" fontWeight="700" fill="white">{p.num}</text>
          </g>
        );
      })}
    </svg>
  );
}

Object.assign(window, { LiveGamePage });
