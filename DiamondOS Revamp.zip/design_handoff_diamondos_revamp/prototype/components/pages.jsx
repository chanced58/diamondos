// Dashboard + Roster + Messages + Practices + Stats + Schedule + Marketing

// ── Dashboard ─────────────────────────────────────────────────────────
function DashboardPage({ setRoute, tone }) {
  const next = { opp: "Ridgeview Hawks", when: "Sat · 3:30 PM", at: "Field 2", record: "8–3" };
  return (
    <div className="page">
      <div className="grid g-3" style={{gap: 16}}>
        {/* Hero: next game */}
        <div className="card card-hero" style={{gridColumn:"span 2", padding: 26, minHeight: 200, display:"flex", flexDirection:"column", justifyContent:"space-between"}}>
          <div>
            <div className="eyebrow" style={{color:"var(--turf-200)"}}>Next up · In 2 days</div>
            <div className="display" style={{fontSize: 44, color:"white", marginTop: 8}}>
              vs <span style={{fontStyle:"italic", fontWeight:600}}>Ridgeview Hawks</span>
            </div>
            <div style={{color:"rgba(255,255,255,.7)", fontSize: 13, marginTop: 6}}>
              {next.when} · {next.at} · Home · <span className="badge badge-safe" style={{marginLeft:4}}>Record {next.record}</span>
            </div>
          </div>
          <div className="row" style={{gap: 10, marginTop: 18}}>
            <button className="btn btn-turf" onClick={() => setRoute("live")}><Ico.ball/> Start scoring</button>
            <button className="btn btn-ghost" style={{color:"white", borderColor:"rgba(255,255,255,.2)"}}>View lineup</button>
            <button className="btn btn-ghost" style={{color:"white", borderColor:"rgba(255,255,255,.2)"}}>Message team</button>
          </div>
        </div>

        {/* Quick stat tiles */}
        <div style={{display:"flex", flexDirection:"column", gap: 16}}>
          <div className="stat-tile">
            <div className="k">Season record</div>
            <div className="v">8<span style={{fontSize:22, color:"var(--app-fg-muted)"}}>–3</span></div>
            <div className="d"><span className="trend trend-up"><Ico.up/> W4</span> · Div lead</div>
          </div>
          <div className="stat-tile">
            <div className="k">Team BA</div>
            <div className="v">.312</div>
            <div className="d"><span className="trend trend-up"><Ico.up/> +.018</span> last 5</div>
          </div>
        </div>
      </div>

      {/* Roster glance + Messages */}
      <div className="grid" style={{gridTemplateColumns: "1.5fr 1fr", gap: 16, marginTop: 16}}>
        <div className="card">
          <div className="between">
            <div>
              <div className="eyebrow">Lineup · vs Hawks</div>
              <h3 className="display" style={{fontSize: 22, margin: "4px 0 0"}}>Probable starters</h3>
            </div>
            <button className="btn btn-ghost btn-sm">Edit <Ico.chev/></button>
          </div>
          <div style={{marginTop: 14, display:"grid", gridTemplateColumns:"1fr 1fr", gap:10}}>
            {[
              { num: 14, name: "E. Chen",    pos: "2B", ba: ".341" },
              { num: 22, name: "J. Reyes",   pos: "SS", ba: ".318" },
              { num: 7,  name: "D. Patel",   pos: "1B", ba: ".298" },
              { num: 9,  name: "M. Rivera",  pos: "CF", ba: ".367" },
              { num: 3,  name: "K. Johnson", pos: "C",  ba: ".279" },
              { num: 11, name: "A. Silva",   pos: "RF", ba: ".255" },
              { num: 6,  name: "T. Moore",   pos: "LF", ba: ".244" },
              { num: 18, name: "B. Park",    pos: "3B", ba: ".310" },
              { num: 21, name: "T. Kowalski",pos: "P",  ba: ".—"   },
            ].map((p, i) => (
              <div key={i} style={{display:"flex", alignItems:"center", gap:10, padding:"8px 10px", borderRadius: 8, background: "var(--app-surface-2)"}}>
                <div style={{width:22, textAlign:"right", fontWeight:700, fontSize:12, color:"var(--app-fg-muted)"}}>{i+1}</div>
                <div className="avatar" style={{width:28, height:28, fontSize:11, background:"linear-gradient(135deg,var(--brand-500),var(--brand-800))"}}>{p.num}</div>
                <div style={{flex:1, minWidth:0}}>
                  <div style={{fontSize:13, fontWeight:600}}>{p.name}</div>
                  <div style={{fontSize:11, color:"var(--app-fg-muted)"}}>{p.pos} · BA {p.ba}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card" style={{display:"flex", flexDirection:"column"}}>
          <div className="between">
            <div>
              <div className="eyebrow">Team chat</div>
              <h3 className="display" style={{fontSize: 22, margin: "4px 0 0"}}>Messages</h3>
            </div>
            <span className="badge badge-info">3 new</span>
          </div>
          <div style={{display:"flex", flexDirection:"column", gap: 10, marginTop: 14}}>
            {[
              { from:"Asst. Coach Ellis", msg:"Cages reserved at 4pm Fri. I'll bring the new tees.", time:"12m", unread:true },
              { from:"Parent · Sara R.",  msg:"M. will be 15m late Sat — doctor visit. OK?", time:"1h", unread:true },
              { from:"Team announcement", msg:"Fundraiser shirts are in the dugout bin. Sizes...", time:"3h", unread:true },
              { from:"#22 J. Reyes",      msg:"Coach can I hit early tomorrow?", time:"yest", unread:false },
            ].map((m, i) => (
              <div key={i} style={{display:"flex", gap:10, alignItems:"flex-start", padding:"10px 0", borderBottom: i<3?"1px solid var(--app-border)":"none"}}>
                <div className="avatar" style={{width:32, height:32, fontSize:12, background: m.unread?"linear-gradient(135deg,var(--turf-500),var(--turf-700))":"var(--gray-200)", color: m.unread?"white":"var(--gray-600)"}}>
                  {m.from.split(" ").map(s=>s[0]).slice(0,2).join("")}
                </div>
                <div style={{flex:1, minWidth:0}}>
                  <div style={{display:"flex", justifyContent:"space-between", gap:8, alignItems:"baseline"}}>
                    <div style={{fontSize:12, fontWeight: m.unread?700:500}}>{m.from}</div>
                    <div style={{fontSize:10, color:"var(--app-fg-subtle)"}}>{m.time}</div>
                  </div>
                  <div style={{fontSize:12, color:"var(--app-fg-muted)", marginTop:2, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis"}}>{m.msg}</div>
                </div>
                {m.unread && <div style={{width:8, height:8, borderRadius:"50%", background:"var(--turf-500)", marginTop:8}}/>}
              </div>
            ))}
          </div>
          <button className="btn btn-ghost btn-sm" style={{marginTop: 10, alignSelf:"flex-start"}} onClick={() => setRoute("messages")}>Open inbox <Ico.chev/></button>
        </div>
      </div>

      {/* Compliance & practice strip */}
      <div className="grid g-3" style={{marginTop: 16}}>
        <div className="card">
          <div className="eyebrow">Compliance</div>
          <h3 className="display" style={{fontSize: 20, margin:"4px 0 10px"}}>Pitch count watch</h3>
          <div style={{display:"flex", flexDirection:"column", gap: 10}}>
            {[
              { num: 21, name:"T. Kowalski", pct: 64, state:"warning"},
              { num: 33, name:"R. Nakamura", pct: 38, state:"safe"},
              { num: 7,  name:"D. Patel",    pct: 92, state:"danger"},
            ].map((p,i) => (
              <div key={i}>
                <div className="between" style={{fontSize:12, marginBottom: 4}}>
                  <span style={{fontWeight: 600}}>#{p.num} {p.name}</span>
                  <span className={`mono`} style={{color: p.state==="danger"?"var(--danger)": p.state==="warning"?"var(--warning)":"var(--safe)", fontWeight:700}}>{p.pct}%</span>
                </div>
                <div style={{height:5, background:"var(--app-surface-2)", borderRadius:999, overflow:"hidden"}}>
                  <div style={{width:`${p.pct}%`, height:"100%", background: p.state==="danger"?"var(--danger)": p.state==="warning"?"var(--warning)":"var(--safe)", transition:"width 400ms var(--ease)"}}/>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="eyebrow">Next practice</div>
          <h3 className="display" style={{fontSize: 20, margin:"4px 0 10px"}}>Fri · 4:00 PM</h3>
          <div style={{fontSize: 13, color:"var(--app-fg-muted)", lineHeight: 1.6}}>
            Focus: Situational hitting · Pickoff drills · Relay throws
          </div>
          <div className="row" style={{marginTop: 12, gap: 8, flexWrap:"wrap"}}>
            <span className="badge badge-info">6 drills</span>
            <span className="badge badge-clay">90 min</span>
            <span className="badge badge-safe">17 RSVP</span>
          </div>
        </div>

        <div className="card">
          <div className="eyebrow">Division</div>
          <h3 className="display" style={{fontSize: 20, margin:"4px 0 10px"}}>Standings · Metro East</h3>
          <div style={{display:"flex", flexDirection:"column", gap: 6, fontSize: 12}}>
            {[
              { t:"Wildcats",   w:8, l:3, us:true },
              { t:"Hawks",      w:7, l:4 },
              { t:"Panthers",   w:6, l:5 },
              { t:"Broncos",    w:4, l:7 },
            ].map((s,i) => (
              <div key={i} className="between" style={{padding:"6px 8px", borderRadius: 6, background: s.us?"var(--turf-50)":"transparent", border: s.us?"1px solid var(--turf-200)":"1px solid transparent"}}>
                <div style={{display:"flex", gap:8, alignItems:"center"}}>
                  <span className="mono" style={{fontSize:11, color:"var(--app-fg-subtle)", width: 14}}>{i+1}</span>
                  <span style={{fontWeight: s.us?700:500}}>{s.t}</span>
                </div>
                <span className="mono" style={{fontWeight: 600}}>{s.w}–{s.l}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Roster ────────────────────────────────────────────────────────────
function RosterPage() {
  const players = [
    { num: 14, name: "Ethan Chen",      pos: "2B/SS",  ba:".341", obp:".419", hr: 2, grade:"So.", status:"active" },
    { num: 22, name: "Javier Reyes",    pos: "SS",     ba:".318", obp:".402", hr: 1, grade:"Jr.", status:"active" },
    { num: 7,  name: "Dev Patel",       pos: "1B",     ba:".298", obp:".385", hr: 4, grade:"Sr.", status:"active" },
    { num: 9,  name: "Marco Rivera",    pos: "CF",     ba:".367", obp:".452", hr: 6, grade:"Sr.", status:"captain" },
    { num: 3,  name: "Kai Johnson",     pos: "C",      ba:".279", obp:".351", hr: 3, grade:"Jr.", status:"active" },
    { num: 11, name: "Andre Silva",     pos: "RF",     ba:".255", obp:".327", hr: 1, grade:"So.", status:"active" },
    { num: 6,  name: "Trey Moore",      pos: "LF",     ba:".244", obp:".311", hr: 0, grade:"Fr.", status:"active" },
    { num: 18, name: "Ben Park",        pos: "3B",     ba:".310", obp:".388", hr: 2, grade:"Jr.", status:"active" },
    { num: 21, name: "Tomas Kowalski",  pos: "P",      ba:".—",   obp:".—",   hr: 0, grade:"Sr.", status:"active" },
    { num: 33, name: "Ryo Nakamura",    pos: "P/OF",   ba:".222", obp:".298", hr: 0, grade:"So.", status:"active" },
    { num: 4,  name: "Owen Lindqvist",  pos: "2B",     ba:".212", obp:".289", hr: 0, grade:"Fr.", status:"injured" },
    { num: 27, name: "Lucas Brooks",    pos: "UT",     ba:".198", obp:".265", hr: 0, grade:"So.", status:"active" },
  ];
  return (
    <div className="page">
      <div className="between" style={{marginBottom: 18}}>
        <div>
          <div className="eyebrow">12 players · 2 captains</div>
          <h2 className="display" style={{fontSize: 32, margin: "4px 0 0"}}>Roster</h2>
        </div>
        <div className="row" style={{gap:8}}>
          <div style={{position:"relative"}}>
            <Ico.search style={{position:"absolute", left: 10, top: "50%", transform:"translateY(-50%)", color:"var(--app-fg-subtle)"}}/>
            <input placeholder="Find player..." style={{padding:"8px 12px 8px 32px", border:"1px solid var(--app-border)", borderRadius:10, background:"var(--app-surface)", color:"var(--app-fg)", width: 200, fontSize: 13}}/>
          </div>
          <button className="btn btn-primary btn-sm"><Ico.plus/> Add player</button>
        </div>
      </div>

      <div className="card" style={{padding: 0, overflow:"hidden"}}>
        <div style={{display:"grid", gridTemplateColumns: "60px 1fr 120px 100px 80px 80px 80px 100px 60px", padding: "12px 16px", background:"var(--app-surface-2)", borderBottom:"1px solid var(--app-border)", fontSize: 11, fontWeight: 700, textTransform:"uppercase", letterSpacing:".08em", color:"var(--app-fg-muted)"}}>
          <div>#</div><div>Name</div><div>Position</div><div>Class</div><div>AVG</div><div>OBP</div><div>HR</div><div>Status</div><div></div>
        </div>
        {players.map((p, i) => (
          <div key={i} style={{display:"grid", gridTemplateColumns: "60px 1fr 120px 100px 80px 80px 80px 100px 60px", padding: "12px 16px", alignItems:"center", borderBottom: i<players.length-1?"1px solid var(--app-border)":"none", fontSize: 13, transition:"background var(--mo) var(--ease)"}}
            onMouseEnter={e => e.currentTarget.style.background = "var(--app-surface-2)"}
            onMouseLeave={e => e.currentTarget.style.background = ""}
          >
            <div className="mono" style={{fontWeight: 700, fontSize: 15, color:"var(--brand-700)"}}>{p.num}</div>
            <div style={{display:"flex", alignItems:"center", gap: 10}}>
              <div className="avatar" style={{width:28, height:28, fontSize:11}}>{p.name.split(" ").map(s=>s[0]).join("")}</div>
              <div>
                <div style={{fontWeight: 600}}>{p.name}</div>
                {p.status==="captain" && <div style={{fontSize:10, color:"var(--clay-600)", fontWeight: 700, letterSpacing:".08em", textTransform:"uppercase"}}>◆ Captain</div>}
              </div>
            </div>
            <div>{p.pos}</div>
            <div style={{color:"var(--app-fg-muted)"}}>{p.grade}</div>
            <div className="mono" style={{fontWeight: 600}}>{p.ba}</div>
            <div className="mono" style={{color:"var(--app-fg-muted)"}}>{p.obp}</div>
            <div className="mono">{p.hr}</div>
            <div>
              {p.status==="injured" ? <span className="badge badge-warning badge-dot">Injured</span>
               : p.status==="captain" ? <span className="badge badge-clay badge-dot">Captain</span>
               : <span className="badge badge-safe badge-dot">Active</span>}
            </div>
            <div style={{textAlign:"right"}}><button className="btn btn-ghost btn-sm" style={{padding: "4px 8px"}}><Ico.chev/></button></div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Messages ──────────────────────────────────────────────────────────
function MessagesPage() {
  const threads = [
    { who:"Team announcement", topic:"Fundraiser shirts", time:"3h", unread:true,  preview:"Shirts are in the dugout bin. Please grab yours and check size before Sat's game." },
    { who:"Asst. Coach Ellis", topic:"Cages reserved",    time:"12m",unread:true,  preview:"Got cages 4pm Fri. Bringing new tees and the L-screen. Need anything else?" },
    { who:"Sara Rivera (Parent)", topic:"Late arrival",   time:"1h", unread:true,  preview:"M. will be 15min late Saturday — doctor appointment. Is that OK with you?" },
    { who:"#22 J. Reyes",      topic:"Early hitting",     time:"yest",unread:false, preview:"Coach can I hit early tomorrow? Want to work on the high-inside fastball." },
    { who:"Booster Club",       topic:"End-of-season banquet", time:"Tue", unread:false, preview:"Booking the venue for May 22. Can you share the final roster count?" },
    { who:"Ridgeview HS AD",    topic:"Saturday matchup", time:"Mon", unread:false, preview:"Confirmed field 2 @ 3:30. Will bring their scorekeeper too." },
  ];
  const [active, setActive] = React.useState(0);
  const t = threads[active];
  return (
    <div className="page" style={{maxWidth: 1280, padding: "0 20px"}}>
      <div className="between" style={{padding: "20px 0 16px"}}>
        <div>
          <div className="eyebrow">Inbox · {threads.filter(x=>x.unread).length} unread</div>
          <h2 className="display" style={{fontSize: 32, margin:"4px 0 0"}}>Messages</h2>
        </div>
        <button className="btn btn-primary btn-sm"><Ico.plus/> New message</button>
      </div>

      <div className="card" style={{padding: 0, overflow:"hidden", display:"grid", gridTemplateColumns: "360px 1fr", minHeight: 520}}>
        {/* Thread list */}
        <div style={{borderRight:"1px solid var(--app-border)", display:"flex", flexDirection:"column"}}>
          <div style={{padding:"12px", borderBottom:"1px solid var(--app-border)"}}>
            <div style={{position:"relative"}}>
              <Ico.search style={{position:"absolute", left: 10, top: "50%", transform:"translateY(-50%)", color:"var(--app-fg-subtle)"}}/>
              <input placeholder="Search messages..." style={{width:"100%", padding:"8px 12px 8px 32px", border:"1px solid var(--app-border)", borderRadius:8, background:"var(--app-surface-2)", color:"var(--app-fg)", fontSize: 13}}/>
            </div>
          </div>
          <div style={{overflow:"auto", flex:1}}>
            {threads.map((x, i) => (
              <div key={i} onClick={() => setActive(i)} style={{padding:"12px 14px", borderBottom:"1px solid var(--app-border)", cursor:"pointer", background: i===active?"var(--brand-50)":"transparent", borderLeft: i===active?"3px solid var(--brand-700)":"3px solid transparent", transition:"all var(--mo) var(--ease)"}}>
                <div className="between" style={{marginBottom: 4}}>
                  <div style={{fontWeight: x.unread?700:500, fontSize: 13, color: i===active?"var(--brand-700)":"var(--app-fg)"}}>{x.who}</div>
                  <div style={{fontSize: 10, color:"var(--app-fg-subtle)"}}>{x.time}</div>
                </div>
                <div style={{fontSize:12, fontWeight:600, color:"var(--app-fg)"}}>{x.topic}</div>
                <div style={{fontSize: 12, color:"var(--app-fg-muted)", marginTop: 2, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis"}}>{x.preview}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Thread view */}
        <div style={{display:"flex", flexDirection:"column"}}>
          <div style={{padding: "18px 22px", borderBottom: "1px solid var(--app-border)"}}>
            <div style={{fontSize: 11, color:"var(--app-fg-muted)", fontWeight: 600, letterSpacing:".08em", textTransform:"uppercase"}}>{t.who}</div>
            <div className="display" style={{fontSize: 22, margin: "4px 0 0"}}>{t.topic}</div>
          </div>
          <div style={{flex:1, padding: 22, display:"flex", flexDirection:"column", gap: 14, overflow: "auto"}}>
            <Bubble from={t.who} time={t.time + " ago"} text={t.preview}/>
            <Bubble from="me" time="just now" text="Got it — thanks for the heads up. I'll note it in the scorebook." mine/>
          </div>
          <div style={{borderTop:"1px solid var(--app-border)", padding: 14, display:"flex", gap: 8, alignItems:"center"}}>
            <input placeholder="Type a message…" style={{flex:1, padding:"10px 14px", border:"1px solid var(--app-border)", borderRadius: 999, background:"var(--app-surface-2)", color:"var(--app-fg)", fontSize: 13}}/>
            <button className="btn btn-primary btn-sm">Send</button>
          </div>
        </div>
      </div>
    </div>
  );
}
function Bubble({ from, time, text, mine }) {
  return (
    <div style={{display:"flex", gap: 10, flexDirection: mine?"row-reverse":"row", alignItems:"flex-end"}}>
      <div className="avatar" style={{width:30, height:30, fontSize:11, background: mine?"linear-gradient(135deg,var(--brand-500),var(--brand-800))":"linear-gradient(135deg,var(--turf-500),var(--turf-700))"}}>{mine?"JR":from.split(" ").map(s=>s[0]).slice(0,2).join("")}</div>
      <div style={{maxWidth: "70%"}}>
        <div style={{padding: "10px 14px", background: mine?"var(--brand-700)":"var(--app-surface-2)", color: mine?"white":"var(--app-fg)", borderRadius: 14, borderBottomRightRadius: mine?4:14, borderBottomLeftRadius: mine?14:4, fontSize: 13, lineHeight: 1.5}}>
          {text}
        </div>
        <div style={{fontSize: 10, color:"var(--app-fg-subtle)", marginTop: 4, textAlign: mine?"right":"left"}}>{time}</div>
      </div>
    </div>
  );
}

// ── Stats ─────────────────────────────────────────────────────────────
function StatsPage() {
  const leaders = [
    { cat:"AVG",  val:".367", who:"#9 M. Rivera" },
    { cat:"OPS",  val:"1.042", who:"#7 D. Patel" },
    { cat:"RBI",  val:"27",    who:"#9 M. Rivera" },
    { cat:"HR",   val:"6",     who:"#9 M. Rivera" },
    { cat:"ERA",  val:"1.84",  who:"#21 T. Kowalski" },
    { cat:"K/9",  val:"10.2",  who:"#21 T. Kowalski" },
  ];
  return (
    <div className="page">
      <div className="between" style={{marginBottom: 20}}>
        <div>
          <div className="eyebrow">Season · 2026</div>
          <h2 className="display" style={{fontSize: 32, margin: "4px 0 0"}}>Team stats</h2>
        </div>
        <div className="seg" style={{width: 260}}>
          <button className="on">Season</button>
          <button>Last 10</button>
          <button>Last 3</button>
        </div>
      </div>

      <div className="grid g-3" style={{gap: 16}}>
        {leaders.map((l, i) => (
          <div key={i} className="card" style={{padding: 22, position:"relative", overflow:"hidden"}}>
            <div className="eyebrow" style={{color:"var(--clay-600)"}}>{l.cat} leader</div>
            <div className="display" style={{fontSize: 52, margin: "6px 0 0", color:"var(--brand-700)"}}>{l.val}</div>
            <div style={{fontSize: 13, color:"var(--app-fg-muted)", marginTop: 4}}>{l.who}</div>
            {/* decorative diamond bg */}
            <div style={{position:"absolute", right:-20, bottom:-20, width: 100, height: 100, transform:"rotate(45deg)", border:"2px solid var(--brand-100)", borderRadius: 8, opacity: 0.5}}/>
          </div>
        ))}
      </div>

      <div className="card" style={{marginTop: 16, padding: 22}}>
        <div className="eyebrow">Spray chart · Team</div>
        <h3 className="display" style={{fontSize: 24, margin: "4px 0 16px"}}>Where we hit</h3>
        <div style={{display:"flex", gap: 24, alignItems:"center", flexWrap:"wrap"}}>
          <SprayChart/>
          <div style={{flex: 1, minWidth: 220}}>
            {[
              { z:"Left field",   pct: 38, n: 52 },
              { z:"Center field", pct: 34, n: 46 },
              { z:"Right field",  pct: 20, n: 27 },
              { z:"Infield",      pct:  8, n: 11 },
            ].map((z,i) => (
              <div key={i} style={{marginBottom: 10}}>
                <div className="between" style={{marginBottom: 4}}>
                  <span style={{fontWeight:600, fontSize:13}}>{z.z}</span>
                  <span className="mono" style={{color:"var(--app-fg-muted)", fontSize:12}}>{z.n} hits · {z.pct}%</span>
                </div>
                <div style={{height: 6, borderRadius: 999, background:"var(--app-surface-2)", overflow:"hidden"}}>
                  <div style={{width: `${z.pct*2}%`, height:"100%", background: "linear-gradient(90deg, var(--turf-500), var(--brand-500))", transition: "width 500ms var(--ease)"}}/>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
function SprayChart() {
  // scatter points by zone
  const pts = [];
  // LF (38)
  for (let i=0;i<22;i++) pts.push({ x: 50 + Math.random()*90, y: 60 + Math.random()*100, z:"lf" });
  // CF (34)
  for (let i=0;i<20;i++) pts.push({ x: 130 + Math.random()*80, y: 30 + Math.random()*90, z:"cf" });
  // RF (20)
  for (let i=0;i<14;i++) pts.push({ x: 200 + Math.random()*80, y: 60 + Math.random()*100, z:"rf" });
  // IF (8)
  for (let i=0;i<8;i++)  pts.push({ x: 150 + (Math.random()-.5)*90, y: 170 + Math.random()*30, z:"if" });
  const col = { lf:"var(--turf-600)", cf:"var(--brand-600)", rf:"var(--clay-500)", if:"var(--gray-500)" };
  return (
    <svg viewBox="0 0 340 260" width={340} height={260} style={{flexShrink:0}}>
      <defs>
        <radialGradient id="spray-turf" cx="50%" cy="90%" r="90%">
          <stop offset="0%" stopColor="var(--turf-400, #4ade80)" stopOpacity=".7"/>
          <stop offset="100%" stopColor="var(--turf-800)" stopOpacity=".95"/>
        </radialGradient>
      </defs>
      <path d="M20 240 Q170 -40 320 240 Z" fill="url(#spray-turf)"/>
      <polygon points="170,230 260,175 170,120 80,175" fill="var(--clay-500)"/>
      <polygon points="170,215 230,175 170,140 110,175" fill="var(--turf-600)"/>
      <polygon points="170,230 260,175 170,120 80,175" fill="none" stroke="rgba(255,255,255,.5)" strokeDasharray="2 3"/>
      {pts.map((p,i) => (
        <circle key={i} cx={p.x} cy={p.y} r="4" fill={col[p.z]} stroke="white" strokeWidth="1" opacity={0.85}/>
      ))}
      <polygon points="165,235 175,235 175,230 170,225 165,230" fill="white"/>
    </svg>
  );
}

// ── Practices ─────────────────────────────────────────────────────────
function PracticesPage() {
  const drills = [
    { t:"Warmup — dynamic stretch", min: 10, cat:"warmup" },
    { t:"Tee work (opposite field)", min: 15, cat:"hit" },
    { t:"Front toss · high inside", min: 15, cat:"hit" },
    { t:"Situational hitting · runner on 2nd", min: 15, cat:"hit" },
    { t:"Pickoff drill — 1B & 2B", min: 15, cat:"field" },
    { t:"Relay throws (OF → cutoff)", min: 15, cat:"field" },
    { t:"Cooldown & chalk talk", min: 5,  cat:"cool" },
  ];
  const catColor = { warmup:"var(--clay-500)", hit:"var(--brand-600)", field:"var(--turf-600)", cool:"var(--gray-500)" };
  const total = drills.reduce((a,d)=>a+d.min,0);
  return (
    <div className="page">
      <div className="between" style={{marginBottom: 18}}>
        <div>
          <div className="eyebrow">Fri · 4:00 PM · {total}min</div>
          <h2 className="display" style={{fontSize: 32, margin: "4px 0 0"}}>Practice plan</h2>
        </div>
        <div className="row" style={{gap:8}}>
          <button className="btn btn-ghost btn-sm">Duplicate</button>
          <button className="btn btn-turf btn-sm">Send to team</button>
        </div>
      </div>

      {/* Timeline strip */}
      <div className="card" style={{padding: 18, marginBottom: 16}}>
        <div className="eyebrow">Timeline</div>
        <div style={{display:"flex", height: 36, marginTop: 10, borderRadius: 8, overflow:"hidden", border:"1px solid var(--app-border)"}}>
          {drills.map((d,i) => (
            <div key={i} title={`${d.t} · ${d.min}min`} style={{flex: d.min, background: catColor[d.cat], borderRight: i<drills.length-1?"2px solid var(--app-surface)":"none", display:"grid", placeItems:"center", color:"white", fontSize: 10, fontWeight: 700}}>
              {d.min}
            </div>
          ))}
        </div>
        <div className="row" style={{gap: 14, marginTop: 10, fontSize: 11, color:"var(--app-fg-muted)"}}>
          <span><span style={{display:"inline-block", width: 10, height: 10, background: catColor.warmup, marginRight: 6, borderRadius: 2, verticalAlign:"middle"}}/>Warmup</span>
          <span><span style={{display:"inline-block", width: 10, height: 10, background: catColor.hit, marginRight: 6, borderRadius: 2, verticalAlign:"middle"}}/>Hitting</span>
          <span><span style={{display:"inline-block", width: 10, height: 10, background: catColor.field, marginRight: 6, borderRadius: 2, verticalAlign:"middle"}}/>Fielding</span>
          <span><span style={{display:"inline-block", width: 10, height: 10, background: catColor.cool, marginRight: 6, borderRadius: 2, verticalAlign:"middle"}}/>Cooldown</span>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns: "1fr 1fr", gap: 16}}>
        <div className="card">
          <div className="eyebrow">Drills</div>
          <div style={{marginTop: 12, display:"flex", flexDirection:"column", gap: 8}}>
            {drills.map((d,i) => (
              <div key={i} style={{display:"flex", alignItems:"center", gap: 12, padding: "10px 12px", border:"1px solid var(--app-border)", borderRadius: 10, background:"var(--app-surface)"}}>
                <div style={{width: 6, alignSelf:"stretch", borderRadius: 3, background: catColor[d.cat]}}/>
                <div style={{flex:1}}>
                  <div style={{fontWeight: 600, fontSize: 13}}>{d.t}</div>
                </div>
                <div className="mono" style={{fontSize: 13, fontWeight: 600, color: "var(--app-fg-muted)"}}>{d.min}<span style={{opacity:.5}}>m</span></div>
                <button className="btn btn-ghost btn-sm" style={{padding:"4px 8px"}}><Ico.chev/></button>
              </div>
            ))}
          </div>
        </div>
        <div className="card">
          <div className="eyebrow">RSVP · 17 of 20</div>
          <h4 className="display" style={{fontSize: 18, margin:"4px 0 10px"}}>Who's coming</h4>
          <div className="grid g-4" style={{gap:8}}>
            {Array.from({length: 20}).map((_, i) => (
              <div key={i} style={{
                padding: "8px 4px", borderRadius: 8, textAlign:"center",
                background: i<17 ? "var(--turf-50)" : "var(--app-surface-2)",
                border: `1px solid ${i<17?"var(--turf-200)":"var(--app-border)"}`,
                fontSize: 11, fontWeight: 600,
                color: i<17 ? "var(--turf-800)" : "var(--app-fg-subtle)"
              }}>
                #{[14,22,7,9,3,11,6,18,21,33,4,27,12,15,5,2,8,10,17,13][i]}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Schedule ──────────────────────────────────────────────────────────
function SchedulePage() {
  const games = [
    { date:"Sat Apr 25", time:"3:30 PM", opp:"Ridgeview Hawks",    loc:"Home · Field 2", status:"upcoming" },
    { date:"Tue Apr 28", time:"4:00 PM", opp:"Fairmont Panthers",  loc:"Away",            status:"upcoming" },
    { date:"Sat May 02", time:"1:00 PM", opp:"Oakdale Broncos",    loc:"Home · Field 2", status:"upcoming" },
    { date:"Thu Apr 22", time:"—",       opp:"Lincoln Lions",      loc:"Home · Field 2", status:"W 7–2",    result:"win" },
    { date:"Sat Apr 18", time:"—",       opp:"St. Mary's",         loc:"Away",            status:"W 5–4",    result:"win" },
    { date:"Tue Apr 15", time:"—",       opp:"Maplewood Mustangs", loc:"Home · Field 2", status:"L 3–6",    result:"loss" },
  ];
  return (
    <div className="page">
      <div className="between" style={{marginBottom: 18}}>
        <div>
          <div className="eyebrow">6 games · 3 upcoming</div>
          <h2 className="display" style={{fontSize: 32, margin: "4px 0 0"}}>Schedule</h2>
        </div>
        <button className="btn btn-primary btn-sm"><Ico.plus/> Add game</button>
      </div>

      <div style={{display:"flex", flexDirection:"column", gap: 10}}>
        {games.map((g, i) => (
          <div key={i} className="card card-interactive" style={{display:"grid", gridTemplateColumns: "100px 1fr 200px 140px 100px", alignItems:"center", gap: 16, padding: "16px 20px"}}>
            <div>
              <div className="mono" style={{fontSize: 11, color:"var(--app-fg-subtle)", fontWeight: 600}}>{g.date.split(" ")[0].toUpperCase()}</div>
              <div className="display" style={{fontSize: 26, lineHeight: 1}}>{g.date.split(" ")[2]}</div>
              <div style={{fontSize: 11, color:"var(--app-fg-muted)"}}>{g.date.split(" ")[1]}</div>
            </div>
            <div>
              <div style={{fontSize: 11, color:"var(--app-fg-muted)", fontWeight: 600, letterSpacing:".08em", textTransform:"uppercase"}}>vs</div>
              <div style={{fontSize: 17, fontWeight: 700, marginTop: 2}}>{g.opp}</div>
            </div>
            <div style={{fontSize: 12, color:"var(--app-fg-muted)"}}>{g.loc}</div>
            <div className="mono" style={{fontSize: 13, fontWeight: 600}}>{g.time}</div>
            <div style={{textAlign:"right"}}>
              {g.result === "win" && <span className="badge badge-safe" style={{fontWeight: 700}}>{g.status}</span>}
              {g.result === "loss" && <span className="badge badge-danger" style={{fontWeight: 700}}>{g.status}</span>}
              {!g.result && <button className="btn btn-ghost btn-sm">Details <Ico.chev/></button>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Marketing landing ─────────────────────────────────────────────────
function MarketingPage({ setRoute }) {
  return (
    <div style={{height:"100vh", overflow:"auto", background:"var(--app-bg)"}}>
      {/* Top nav */}
      <div style={{position:"sticky", top:0, zIndex: 10, background:"rgba(255,255,255,.9)", backdropFilter:"blur(8px)", borderBottom:"1px solid var(--app-border)", padding: "14px 32px", display:"flex", justifyContent:"space-between", alignItems:"center"}}>
        <div className="row" style={{gap: 10}}>
          <BrandMark/>
          <div className="display" style={{fontSize: 18}}>DiamondOS</div>
        </div>
        <div className="row" style={{gap: 8}}>
          <button className="btn btn-ghost btn-sm" onClick={() => setRoute("dash")}>Sign in</button>
          <button className="btn btn-turf btn-sm">Start free</button>
        </div>
      </div>

      {/* Hero */}
      <section style={{padding:"80px 32px 60px", maxWidth: 1200, margin:"0 auto", textAlign:"center", position:"relative"}}>
        <div style={{position:"absolute", inset: 0, pointerEvents:"none", opacity: 0.35, backgroundImage: "radial-gradient(ellipse at 50% 0%, var(--turf-100), transparent 60%)"}}/>
        <div className="eyebrow" style={{color:"var(--turf-700)"}}>Built for dugouts · Not desks</div>
        <h1 className="display" style={{fontSize: "clamp(48px, 7vw, 88px)", margin: "16px 0 0", maxWidth: 900, marginInline:"auto", lineHeight: 0.95}}>
          Coach like you <span style={{fontStyle:"italic", color:"var(--turf-700)"}}>mean</span> it.
        </h1>
        <p style={{fontSize: 19, color:"var(--app-fg-muted)", maxWidth: 620, margin: "20px auto 0", lineHeight: 1.55}}>
          Scorekeep pitch-by-pitch, message the whole team in a tap, and see every stat follow every player —&nbsp;season after season.
        </p>
        <div className="row" style={{justifyContent:"center", gap:10, marginTop: 28}}>
          <button className="btn btn-turf btn-lg">Start free — 30 days</button>
          <button className="btn btn-ghost btn-lg" onClick={() => setRoute("live")}>See it live →</button>
        </div>

        {/* Product mock preview */}
        <div style={{marginTop: 48, padding: 16, background:"var(--app-surface)", border:"1px solid var(--app-border)", borderRadius: 20, boxShadow: "0 30px 60px -30px rgba(0,0,0,.3)"}}>
          <div style={{borderRadius: 14, background: "linear-gradient(135deg, var(--brand-700), var(--brand-900))", padding: 40, color:"white", position:"relative", overflow:"hidden"}}>
            <div className="eyebrow" style={{color:"var(--turf-200)"}}>Top 4 · Live</div>
            <div className="display" style={{fontSize: 44, margin: "10px 0"}}>Wildcats 4 <span style={{fontStyle:"italic", opacity:.5}}>—</span> 2 Hawks</div>
            <div style={{color:"rgba(255,255,255,.7)"}}>Runners on 1st & 2nd · 1 out · #9 Rivera at bat · 2-1 count</div>
            <div style={{position:"absolute", right: 30, top: 30}}>
              <DiamondField runners={{first:true, second:true, third:false}} size={140} variant="editorial"/>
            </div>
          </div>
        </div>
      </section>

      {/* Three-up value props */}
      <section style={{padding:"40px 32px 80px", maxWidth: 1200, margin:"0 auto"}}>
        <div className="grid g-3" style={{gap: 24}}>
          {[
            { eye:"Scorekeeping", head:"Tap-and-go.", body:"Record every pitch without lifting your eyes from the field. Auto-counts strikes, outs, runners — so you stay a coach, not a scribe." },
            { eye:"Communication", head:"One tap, whole team.", body:"Game change? Rain delay? Cages moved? Reach every parent and player instantly — then see exactly who saw it." },
            { eye:"Stats",         head:"Follow the player.", body:"When they move up, their numbers move with them. Every season, every team, one home." },
          ].map((c, i) => (
            <div key={i} style={{padding: 24, borderLeft: "3px solid var(--turf-500)", background: "var(--app-surface)"}}>
              <div className="eyebrow" style={{color:"var(--turf-700)"}}>{c.eye}</div>
              <h3 className="display" style={{fontSize: 28, margin:"10px 0"}}>{c.head}</h3>
              <p style={{fontSize: 14, color:"var(--app-fg-muted)", lineHeight: 1.6, margin: 0}}>{c.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Quote band */}
      <section style={{padding:"60px 32px", background:"var(--brand-900)", color:"white", position:"relative", overflow:"hidden"}}>
        <div style={{maxWidth: 900, margin:"0 auto", textAlign:"center", position:"relative"}}>
          <div className="display-it" style={{fontSize: "clamp(26px, 4vw, 40px)", lineHeight: 1.25, fontWeight: 600}}>
            "My players can see their growth. Parents stop asking the same questions. I coach the game, not the spreadsheet."
          </div>
          <div style={{marginTop: 20, fontSize: 13, color:"rgba(255,255,255,.65)", letterSpacing:".05em"}}>
            — Coach M. Delgado · Varsity HC · 14 seasons
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section style={{padding:"60px 32px 80px", textAlign:"center", maxWidth: 800, margin:"0 auto"}}>
        <h2 className="display" style={{fontSize: 44, margin: 0}}>Get the dugout on your side.</h2>
        <p style={{color:"var(--app-fg-muted)", marginTop: 14}}>Free through your next full season. No card required.</p>
        <button className="btn btn-turf btn-lg" style={{marginTop: 20}}>Start your season free →</button>
      </section>
    </div>
  );
}

Object.assign(window, { DashboardPage, RosterPage, MessagesPage, PracticesPage, StatsPage, SchedulePage, MarketingPage });
