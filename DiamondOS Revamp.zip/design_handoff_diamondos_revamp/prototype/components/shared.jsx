// DiamondOS Revamp — shared primitives

const { useState, useEffect, useMemo, useRef, useCallback } = React;

// ── Icons (inline SVG, hand-drawn to match editorial feel) ─────────────
const Ico = {
  dash: (p) => (<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 2l10 10-10 10L2 12z"/></svg>),
  sched: (p) => (<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>),
  ball: (p) => (<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" {...p}><circle cx="12" cy="12" r="9"/><path d="M5.5 7c3 2 9 2 13 0M5.5 17c3-2 9-2 13 0"/></svg>),
  stats: (p) => (<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M3 20V10M9 20V4M15 20v-8M21 20v-6"/></svg>),
  msg: (p) => (<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M4 6h16v10H8l-4 4z"/></svg>),
  team: (p) => (<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M17 20v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="10" cy="8" r="3"/><path d="M21 20v-2a4 4 0 0 0-3-3.87M17 4.13a4 4 0 0 1 0 7.75"/></svg>),
  prac: (p) => (<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M6 4h4v16H6zM14 8h4v12h-4z"/><path d="M4 12h2M18 14h2"/></svg>),
  bell: (p) => (<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8M10 21a2 2 0 0 0 4 0"/></svg>),
  plus: (p) => (<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" {...p}><path d="M12 5v14M5 12h14"/></svg>),
  search: (p) => (<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3-3"/></svg>),
  up: (p) => (<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m6 15 6-6 6 6"/></svg>),
  chev: (p) => (<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m9 18 6-6-6-6"/></svg>),
  undo: (p) => (<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M3 7v6h6"/><path d="M3 13a9 9 0 1 0 3-7L3 9"/></svg>),
};

// ── Brand mark (diamond with subtle gradient) ─────────────────────────
function BrandMark({ size=34 }) {
  return (
    <div className="sb-logo" style={{ width:size, height:size, fontSize: size*0.52 }}>
      <span style={{transform:"translateY(-1px)"}}>◆</span>
    </div>
  );
}

// ── Sidebar ───────────────────────────────────────────────────────────
function Sidebar({ route, setRoute, liveGame }) {
  const nav = [
    { k: "dash",     label: "Dashboard",   icon: <Ico.dash/> },
    { k: "live",     label: "Live Game",   icon: <Ico.ball/>, badge: liveGame ? "LIVE" : null },
    { k: "schedule", label: "Schedule",    icon: <Ico.sched/> },
    { k: "roster",   label: "Roster",      icon: <Ico.team/> },
    { k: "practice", label: "Practices",   icon: <Ico.prac/> },
    { k: "stats",    label: "Stats",       icon: <Ico.stats/> },
    { k: "messages", label: "Messages",    icon: <Ico.msg/>, badge: 3 },
  ];
  return (
    <aside className="sidebar">
      <div className="sb-brand">
        <BrandMark/>
        <div>
          <div className="sb-team">Westfield Wildcats</div>
          <div className="sb-team-sub">Varsity · 14U</div>
        </div>
      </div>

      <div className="sb-next" onClick={() => setRoute("live")} style={{cursor:"pointer"}}>
        <span className="live"><span className="pulse"/> Live · Top 4</span>
        <div className="matchup">vs Ridgeview Hawks</div>
        <div className="score mono"><span>4</span><span className="vs">—</span><span>2</span></div>
        <div className="inning">Runners on 1st &amp; 2nd · 1 out</div>
      </div>

      <nav className="sb-nav" style={{marginTop: 14}}>
        {nav.map(n => (
          <div key={n.k} className={`sb-item ${route===n.k?"active":""}`} onClick={() => setRoute(n.k)}>
            <span className="ico">{n.icon}</span>
            <span>{n.label}</span>
            {n.badge && (
              typeof n.badge === "number"
                ? <span className="badge-count">{n.badge}</span>
                : <span className="badge-count" style={{background:"#dc2626",color:"white"}}>{n.badge}</span>
            )}
          </div>
        ))}
      </nav>

      <div className="sb-foot">
        <div className="avatar">JR</div>
        <div style={{flex:1, minWidth:0}}>
          <div className="name">Coach J. Rivera</div>
          <div className="role">Head Coach</div>
        </div>
        <button className="btn btn-sm btn-ghost" style={{padding:"4px 8px", border:"none", color:"rgba(255,255,255,.55)"}}>⚙</button>
      </div>
    </aside>
  );
}

// ── Topbar ────────────────────────────────────────────────────────────
function Topbar({ title, sub, actions, eyebrow, liveChip }) {
  return (
    <div className="topbar">
      <div>
        {eyebrow && <div className="eyebrow" style={{marginBottom: 4}}>{eyebrow}</div>}
        <div style={{display:"flex", alignItems:"center", gap: 12}}>
          <h1>{title}</h1>
          {liveChip && <span className="live-chip"><span className="pulse"/>Live</span>}
        </div>
        {sub && <div className="sub">{sub}</div>}
      </div>
      <div className="topbar-actions">{actions}</div>
    </div>
  );
}

// ── Diamond field SVG (with runners) ──────────────────────────────────
function DiamondField({ runners = { first:false, second:false, third:false }, size = 220, variant = "editorial" }) {
  // variant: 'editorial' (chalk-on-turf), 'utilitarian' (tokens-only), 'energetic' (glow)
  const isEditorial = variant === "editorial";
  const isEnergetic = variant === "energetic";
  return (
    <svg viewBox="0 0 240 220" width={size} height={size} style={{display:"block"}}>
      <defs>
        <radialGradient id="turfG" cx="50%" cy="60%" r="70%">
          <stop offset="0%" stopColor="var(--turf-500)" stopOpacity="0.9"/>
          <stop offset="60%" stopColor="var(--turf-700)" stopOpacity="0.95"/>
          <stop offset="100%" stopColor="var(--turf-900)"/>
        </radialGradient>
        <linearGradient id="dirtG" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="#c97c4a"/>
          <stop offset="100%" stopColor="#8a4a1f"/>
        </linearGradient>
        <filter id="glowBase" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="3"/>
        </filter>
      </defs>

      {/* Outfield arc */}
      <path d="M20 180 Q120 -30 220 180 Z" fill={isEditorial ? "url(#turfG)" : "var(--turf-700)"}/>
      {/* Infield diamond (clay) */}
      <polygon points="120,50 195,125 120,200 45,125" fill={isEditorial ? "url(#dirtG)" : "var(--clay-500)"}/>
      {/* Infield grass */}
      <polygon points="120,78 170,125 120,172 70,125" fill={isEditorial ? "url(#turfG)" : "var(--turf-600)"}/>

      {/* Base path chalk */}
      <polygon points="120,50 195,125 120,200 45,125" fill="none" stroke="rgba(255,255,255,.35)" strokeWidth="1.2" strokeDasharray="2 3"/>

      {/* Bases */}
      {[
        { x: 120, y: 200, k: "home" },
        { x: 195, y: 125, k: "first",  on: runners.first  },
        { x: 120, y: 50,  k: "second", on: runners.second },
        { x: 45,  y: 125, k: "third",  on: runners.third  },
      ].map(b => (
        <g key={b.k} transform={`translate(${b.x} ${b.y}) rotate(45)`}>
          {b.on && isEnergetic && (
            <rect x="-16" y="-16" width="32" height="32" fill="var(--brand-500)" opacity=".4" filter="url(#glowBase)"/>
          )}
          <rect
            x={b.k==="home" ? -10 : -12}
            y={b.k==="home" ? -10 : -12}
            width={b.k==="home" ? 20 : 24}
            height={b.k==="home" ? 20 : 24}
            fill={b.on ? "var(--brand-500)" : "white"}
            stroke={b.on ? "var(--brand-700)" : "rgba(255,255,255,.8)"}
            strokeWidth="2"
            rx="2"
          />
        </g>
      ))}

      {/* Pitcher mound */}
      <circle cx="120" cy="125" r="10" fill={isEditorial ? "url(#dirtG)" : "var(--clay-500)"} stroke="rgba(255,255,255,.5)" strokeWidth="1"/>
    </svg>
  );
}

// ── Count dots with pinging ───────────────────────────────────────────
function CountDots({ balls, strikes, outs, pinged }) {
  const make = (n, max, cls, pingKey) =>
    Array.from({length: max}).map((_, i) => (
      <span key={i} className={`d ${i<n?cls:""} ${pinged===pingKey && i===n-1 ? "ping" : ""}`}/>
    ));
  return (
    <div className="row" style={{gap: 18, flexWrap:"wrap"}}>
      <div className="count-dots"><span className="lbl">B</span>{make(balls,4,"on-b","b")}</div>
      <div className="count-dots"><span className="lbl">S</span>{make(strikes,3,"on-s","s")}</div>
      <div className="count-dots"><span className="lbl">O</span>{make(outs,3,"on-o","o")}</div>
    </div>
  );
}

// ── Tweaks panel ──────────────────────────────────────────────────────
function TweaksPanel({ open, theme, setTheme, motion, setMotion, density, setDensity, tone, setTone }) {
  if (!open) return null;
  const Seg = ({ value, set, options }) => (
    <div className="seg">
      {options.map(o => (
        <button key={o.v} className={value===o.v?"on":""} onClick={() => set(o.v)}>{o.l}</button>
      ))}
    </div>
  );
  return (
    <div className="tweaks">
      <h4>Tweaks</h4>
      <div className="tweaks-row">
        <label>Theme</label>
        <Seg value={theme} set={setTheme} options={[
          {v:"light",  l:"Light"},
          {v:"dark",   l:"Dark"},
          {v:"dugout", l:"Dugout"},
        ]}/>
      </div>
      <div className="tweaks-row">
        <label>Density</label>
        <Seg value={density} set={setDensity} options={[
          {v:"compact",   l:"Compact"},
          {v:"comfortable",l:"Comfort"},
          {v:"spacious",  l:"Spacious"},
        ]}/>
      </div>
      <div className="tweaks-row">
        <label>Motion</label>
        <Seg value={motion} set={setMotion} options={[
          {v:"on",  l:"On"},
          {v:"off", l:"Off"},
        ]}/>
      </div>
      <div className="tweaks-row">
        <label>Visual tone</label>
        <Seg value={tone} set={setTone} options={[
          {v:"utilitarian", l:"Utility"},
          {v:"editorial",   l:"Editorial"},
          {v:"energetic",   l:"Energetic"},
        ]}/>
      </div>
      <div style={{marginTop:10, fontSize:11, color:"var(--app-fg-subtle)"}}>
        Values persist to disk via design-mode.
      </div>
    </div>
  );
}

// Export globals
Object.assign(window, {
  React, useState, useEffect, useMemo, useRef, useCallback,
  Ico, BrandMark, Sidebar, Topbar, DiamondField, CountDots, TweaksPanel,
});
