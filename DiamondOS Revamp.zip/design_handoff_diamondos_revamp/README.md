# Handoff: DiamondOS Revamp

## Overview

A full UI revamp of DiamondOS — a baseball team-management app for head coaches. The
revamp preserves DiamondOS's existing design-system tokens (navy brand palette,
Inter body, pitch-count semantics, count-dot colors, diamond motif) while adding:

- **Stadium-turf green** as a real secondary brand color (not just a semantic).
- **Fraunces** (serif display) for editorial headings.
- **Dugout-night** theme alongside Light and Dark.
- **Density** control (Compact / Comfortable / Spacious).
- **Motion** control and **Visual tone** (Utility / Editorial / Energetic) — the
  tone prop threads through the diamond/strike-zone SVG renders.
- Baseball-native motifs throughout: diamond-field SVG with runners, strike-zone
  heatmap, spray chart, count dots with ping animation, pitch-count progress bars,
  inning-by-inning scoreboard grid.

The overarching product goal: **empowerment** for head coaches, making
scorekeeping and team communication feel fast, glanceable, and dugout-ready
(iPad in the sun, one thumb, eyes on the field).

## About the Design Files

The files in `prototype/` are **design references created in HTML** — they are
prototypes showing intended look and behavior, **not production code to copy
directly**. Your task is to recreate these designs in DiamondOS's existing
codebase using its established patterns:

- `apps/web/` — recreate each screen using the existing Next.js/React + Tailwind stack.
- `packages/ui/` — extract the reusable primitives (see §Primitives) into the
  shared component library.
- `apps/mobile/` (if present) — the Live Game screen is designed iPad-first;
  a React Native / Expo port should mirror the layout on tablet breakpoints.

Use the prototype files as:
1. **Visual spec** (pixel-accurate layout, exact colors, exact copy).
2. **Behavior spec** (state transitions in `live_game.jsx` describe the scoring
   state machine).
3. **Token source** (`styles/app.css` defines every new token and theme).

## Fidelity

**High-fidelity.** All colors, typography, spacing, radii, and interactions are
final. Recreate pixel-perfectly. Where the prototype uses inline styles for
one-off layouts, migrate those into Tailwind utilities or component-scoped
styles per your codebase convention.

## Screens / Views

The prototype has 8 views. Order of rollout recommendation in §Implementation Order.

### 1. Sidebar (global chrome)
- **Purpose:** Persistent nav across all authenticated views. 248 px fixed width.
- **Layout (top → bottom):**
  - Brand block: 34×34 diamond logo (linear-gradient 135deg from `--brand-500` to
    `--turf-600`) + team name + team subtitle.
  - "Live / Next up" card: rounded 12px, `rgba(255,255,255,.05)` bg. Contains a
    pulsing red LIVE chip (`keyframes livepulse`, 1.6s infinite), matchup, mono
    score "4 — 2", and inning line. Clickable → navigates to Live Game.
  - Nav list: 7 items (Dashboard, Live Game, Schedule, Roster, Practices, Stats,
    Messages). Active item gets `--app-sidebar-active` background + a 3px
    turf-to-brand gradient rail on the left. Badge count pill (turf green) for
    Messages; a red "LIVE" pill on Live Game when active.
  - Footer: 32px round clay-gradient avatar + name + role + settings gear.
- **Tokens:** `--app-sidebar-bg` (`#1e2d6b` light; `#0a1024` dark; `#071008` dugout).
- **Watermark:** subtle green radial gradient bottom-right at 10% opacity.

### 2. Dashboard (`dash`)
- **Purpose:** At-a-glance landing — game day orientation.
- **Layout (3-col grid, 16px gap):**
  - **Row 1:** Hero "Next up" card (spans 2 cols) + two stacked stat tiles (Season
    record, Team BA).
  - **Row 2:** Lineup card (1.5fr) + Messages preview (1fr).
  - **Row 3:** 3-up — Pitch-count watch, Next practice, Division standings.
- **Hero card:** `.card-hero` — navy gradient 135deg from `--brand-700` through
  `--brand-900` to `#0a1240`. Diamond chalk conic-gradient motif in bottom-right
  corner (see `::after` in `app.css`). White text; turf-green eyebrow; 44px
  Fraunces headline "vs *Ridgeview Hawks*" (second word italic). Turf CTA
  "Start scoring" + two ghost buttons (white borders at 20% opacity).
- **Stat tiles:** 16px radius, 1px border, `--pad-card` padding. 11px uppercase
  eyebrow key; 34px Fraunces value; 12px muted delta with trend pill.
- **Lineup card:** 2-col grid of 9 batter rows. Each row: position number (right-aligned 22px) + 28px navy-gradient avatar (jersey #) + name + pos/BA.
- **Messages preview:** 4 most recent threads with unread dot, 32px turf-gradient avatars for unread, gray avatars for read.
- **Pitch-count watch:** 3 progress bars. Color by severity — `--safe` <75%, `--warning` 75–89%, `--danger` ≥90%.

### 3. Live Game (`live`) — **hero screen**
- **Purpose:** Dugout scorekeeping, pitch-by-pitch. iPad-first. Optimized for
  thumb reach and glanceability.
- **Layout (top → bottom):**
  1. **Scoreboard hero card** — full-width `.card-hero` at 18px radius, 24px
     padding. Live chip + "Top of 4" eyebrow, 46px Fraunces title, home/away
     score tiles (64px Fraunces digits, mono font-family fallback), 9-inning
     grid (80px label col + 9×1fr innings + R/H/E 50px cols).
  2. **3-col main grid (1fr 1.1fr 1fr, 16px gap):**
     - **Left — Field card:** `DiamondField` SVG (240px) with runner state,
       "at bat" batter row (32px avatar + name + line), pitcher row + pitch-count
       progress with `--warning` fill.
     - **Center — Inputs:** Count dots with ping animation on increment. 3-col
       grid of pitch buttons (Ball / Called K / Swing K / Foul / In Play; In Play
       spans 3). 3-col grid of result buttons (Out / 1B / 2B / 3B / HR / Error).
       Bottom: "Last event" ticker — info-blue pill that re-animates on change.
     - **Right — Heatmap + Play log:** `StrikeZoneHeatmap` SVG 200×260 with
       numbered pitch markers colored by call. Play log card with colored bullets
       by event type (hit=turf, out=red, walk=green, at bat=brand).
- **State machine (see `live_game.jsx`):**
  - `balls`, `strikes`, `outs`, `inning {num, half}`, `score {home, away}`,
    `runners {first, second, third}`, `pitches[]`, `history[]`, `lastEvent`.
  - Ball 4 → walk, advance forced runners, reset count.
  - Strike 3 → out, reset count. 3rd out flips half-inning and clears bases.
  - Foul → strike unless already 2. In Play → awaits result button.
  - Result "out" / "1B" / "2B" / "3B" / "HR" / "err" → `advance(bases)`
    pushes runners, scores runs that reach home, resets count.
- **Interactions:** Every count increment triggers `ping(key)` — 450ms scale
  (1 → 1.55 → 1) animation on the last-lit dot. Buttons scale-to-97% on active.

### 4. Roster (`roster`)
- Table with 60/1fr/120/100/80/80/80/100/60 columns: # · Name · Pos · Class · AVG
  · OBP · HR · Status · action.
- Rows hover → `--app-surface-2` background.
- Name cell: 28px avatar + name + optional "◆ Captain" micro-label (clay).
- Status badge colors: Active (safe/turf), Injured (warning), Captain (clay).
- Top-right: search input with left-padded icon (search SVG at 10px/50%) + "Add player" primary button.

### 5. Messages (`messages`)
- Two-pane: 360px thread list + 1fr thread view inside a single card.
- Thread list rows: unread → bold name, 3px navy left-rail when selected, turf dot.
- Thread view: header (uppercase who + 22px Fraunces topic) + bubbles + composer.
- Bubble: 14px radius, opposite corner clipped to 4px for tail. Mine = navy gradient on white; theirs = `--app-surface-2`.
- Composer: full-width pill input + primary Send button.

### 6. Practices (`practice`)
- **Header:** eyebrow with date/duration, 32px Fraunces title, Duplicate + turf "Send to team".
- **Timeline strip:** Flex-grow segments per drill, colored by category (warmup=clay, hit=brand, field=turf, cool=gray). White 2px dividers, minute count in each segment. Legend row below.
- **2-col grid:**
  - **Drills list:** Bordered rows, 6px colored rail on left, title + mono "15m" + chevron.
  - **RSVP grid:** 4-col jersey # pills; attending = turf-tinted, declined = gray.

### 7. Stats (`stats`)
- **Leader cards (3×2 grid):** 52px Fraunces value in `--brand-700`, clay eyebrow "AVG leader" etc., attribution, decorative rotated diamond outline in bottom-right corner at 50% opacity.
- **Spray chart card:** 340×260 SVG with turf radial gradient, clay infield, dashed chalk basepath, home plate pentagon, scattered hit markers colored by zone (lf=turf, cf=brand, rf=clay, if=gray). Zone breakdown bars beside it with turf→brand gradient fills.
- Segmented period control (Season / Last 10 / Last 3), 260px wide.

### 8. Schedule (`schedule`)
- Row cards: 100/1fr/200/140/100 grid. Date column = mono dayname, 26px Fraunces
  day number, muted month. Opponent block: "vs" eyebrow + 17px bold name.
- Results → badge (safe for W, danger for L). Upcoming → "Details" ghost button.
- `.card-interactive` hover: translateY(-1px) + soft shadow.

### 9. Marketing (`marketing`)
- Sticky top nav: logo + "DiamondOS" wordmark, Sign in + turf "Start free".
- **Hero section:** centered. Turf eyebrow "Built for dugouts · Not desks",
  `clamp(48px, 7vw, 88px)` Fraunces headline "Coach like you *mean* it." (mean
  italic + turf). Body copy + two CTAs.
- **Product mock:** embedded scoreboard card with `DiamondField` floating top-right.
- **3-up value props:** 24px padding, 3px turf left border, turf eyebrow, 28px
  Fraunces head, 14px muted body. (Scorekeeping / Communication / Stats.)
- **Quote band:** `--brand-900` bg, 40px italic Fraunces pull-quote, attribution.
- **Footer CTA:** 44px Fraunces head + turf CTA.

## Interactions & Behavior

### Navigation
Single-page with `route` state and localStorage persistence (`dos_route` key).
Side effects:
- Sidebar click → setRoute(k).
- "Start scoring" CTAs everywhere → setRoute("live").
- Clicking the sidebar live card → setRoute("live").
- Page mount animates with `@keyframes fadeUp` (opacity 0 + y6 → 1 + y0, 320ms).

### Live Game state transitions
See `components/live_game.jsx` — `onPitch(type)`, `onResult(res)`, `advance(bases)`,
`walkRunners()`, `homeRun()`, `addOut()`. Wire these to your real scoring API
endpoints; the prototype keeps everything in local React state.

### Animations (all use `--ease: cubic-bezier(.22,1,.36,1)`, `--mo: 220ms`)
- **livepulse** — red dot box-shadow ring ramp, 1.6s infinite.
- **ping** — count-dot scale burst, 450ms, triggered on increment.
- **fadeUp** — page mount + lastEvent changes, 320ms.
- **Card hover** — `.card-interactive`: translateY(-1px) + `0 8px 24px -12px rgba(0,0,0,.15)`.
- **Button active** — `transform: translateY(1px)` on press; pitch buttons also `scale(.97)` on mousedown.
- **Progress bars** — `width` transitions at 400–500ms ease.

All of the above honor `[data-motion="off"]` which nukes animation-duration
and transition-duration globally.

### Tweaks panel
Floating bottom-right (300px wide, 16px radius, backdrop-blur). Four segmented
controls: Theme / Density / Motion / Visual tone. Controlled via `data-theme`,
`data-density`, `data-motion` attributes on `<html>` and a `tone` prop passed
down into `DiamondField`.

In the prototype the panel is shown/hidden via postMessage contract
(`__activate_edit_mode` / `__deactivate_edit_mode`) — in your app, surface it
as a user-settings page (or a quick-toggle menu in the topbar).

## State Management

### Global
- `route` — which page is shown. **Persist:** localStorage.
- `theme` — `"light" | "dark" | "dugout"`. **Persist:** user profile.
- `density` — `"compact" | "comfortable" | "spacious"`. **Persist:** user profile.
- `motion` — `"on" | "off"`. **Persist:** user profile + respect `prefers-reduced-motion`.
- `tone` — `"utilitarian" | "editorial" | "energetic"`. (Optional — org-level brand setting.)

### Live Game (per-game document / store)
- `gameId`, `inning {num, half}`, `score {home, away}`, `outs`, `balls`, `strikes`,
  `runners {first, second, third}`, `atBatPlayerId`, `pitcherId`, `pitches[]`
  (each: `{x, y, call, num, timestamp}`), `history[]` (play-by-play log).
- Every action should be a server-side append-only event (source of truth for
  replay / undo / spectator sync).

### Data-fetching requirements
- Team, roster, current lineup.
- Current game state (subscribe for live updates — WebSocket or SSE).
- Inbox threads + unread counts.
- Pitch-count totals per pitcher across games for the compliance widget.
- Season leaderboards + spray-chart aggregation.
- Division standings.

## Design Tokens

All tokens live in `prototype/styles/app.css`. The base DiamondOS tokens in
`tokens.css` are preserved unchanged.

### New palette

```
--turf-50:  #f0fdf4;  --turf-100: #dcfce7;  --turf-200: #bbf7d0;
--turf-500: #22c55e;  --turf-600: #16a34a;  --turf-700: #15803d;
--turf-800: #166534;  --turf-900: #14532d;

--clay-50:  #fdf4ed;  --clay-200: #f4d7b4;  --clay-400: #d58b4a;
--clay-500: #c2703a;  --clay-600: #a1552a;  --clay-700: #7a3f1f;
```

### Theme surfaces

```
/* Light (default) */
--app-bg:#f9fafb  --app-surface:#ffffff  --app-surface-2:#f9fafb
--app-border:#e5e7eb  --app-fg:#111827  --app-fg-muted:#6b7280  --app-fg-subtle:#9ca3af
--app-sidebar-bg:#1e2d6b  --app-sidebar-active:#1e3a8a

/* Dark */
--app-bg:#0b1220  --app-surface:#111a2e  --app-surface-2:#0f172a
--app-border:#1f2c4a  --app-fg:#e5edff  --app-fg-muted:#9aa8c7
--app-sidebar-bg:#0a1024  --app-sidebar-active:#1b2a58

/* Dugout (field-lights night) */
--app-bg:#08120a  --app-surface:#0d1a10  --app-surface-2:#0a160c
--app-border:#1a3320  --app-fg:#f2f7ee  --app-fg-muted:#9fb298
--app-sidebar-bg:#071008  --app-sidebar-active:#143c1e
--app-brand:#22c55e  --app-brand-2:#4ade80  /* turf takes over as primary */
```

### Typography

```
--font-display: 'Fraunces', 'Georgia', serif;   /* headings, stat numerals, quotes */
--font-sans:    'Inter', system-ui, …;          /* body (unchanged from base) */
--font-mono:    'Roboto Mono', ui-monospace, Menlo, monospace;  /* scores, counts, times */
```

Fraunces weights used: 600 (italic emphasis), 700, 800, 900. Load via Google
Fonts import in `app.css`.

### Spacing (density-aware)

```
--gap-xs: 6px   --gap-sm: 10px  --gap-md: 14px  --gap-lg: 20px  --gap-xl: 28px
--pad-card: 18px   --row-h: 44px
```

Compact scales `--gap-md/lg/xl` + `--pad-card` + `--row-h` down;
Spacious scales them up. See `[data-density="..."]` blocks.

### Radii (inherit from base)

`--r-sm:6px`, `--r-md:8px`, `--r-lg:12px` (cards), `--r-xl:16px` (hero panels),
`--r-full:9999px` (pills).

### Shadows

```
--shadow-sm: 0 1px 2px rgba(0,0,0,.05)
--shadow-lg: 0 8px 24px rgba(0,0,0,.12)

/* custom: */
.card-interactive hover → 0 8px 24px -12px rgba(0,0,0,.15)
.btn-primary           → inset 0 1px 0 rgba(255,255,255,.15), 0 6px 16px -6px rgba(29,78,216,.55)
.btn-turf              → inset 0 1px 0 rgba(255,255,255,.25), 0 6px 16px -6px rgba(22,163,74,.55)
.tweaks panel          → 0 20px 40px -12px rgba(0,0,0,.35)
.hero mock             → 0 30px 60px -30px rgba(0,0,0,.3)
```

### Motion

```
--mo: 220ms
--ease: cubic-bezier(.22,1,.36,1)
```

## Primitives to extract into `packages/ui`

These are the reusable SVG + UI primitives you should lift out of the prototype.

| Primitive            | File                              | Props                                                         |
|----------------------|-----------------------------------|---------------------------------------------------------------|
| `DiamondField`       | `components/shared.jsx`           | `runners {first,second,third}`, `size`, `variant` (tone)      |
| `CountDots`          | `components/shared.jsx`           | `balls`, `strikes`, `outs`, `pinged` (animation trigger key)  |
| `StrikeZoneHeatmap`  | `components/live_game.jsx`        | `pitches[]: {x:0-1, y:0-1, call, num}`                        |
| `SprayChart`         | `components/pages.jsx`            | (takes hardcoded pts array now — make data-driven)            |
| `PitchBtn`           | `components/live_game.jsx`        | `label`, `tone`, `hot`, `onClick`, `wide`                     |
| `Sidebar`            | `components/shared.jsx`           | `route`, `setRoute`, `liveGame`                               |
| `Topbar`             | `components/shared.jsx`           | `title`, `sub`, `eyebrow`, `liveChip`, `actions`              |
| `StatTile`           | (inline in `pages.jsx`)           | `label`, `value`, `delta`, `trend`                            |
| `Bubble` (message)   | `components/pages.jsx`            | `from`, `time`, `text`, `mine`                                |
| `LiveChip`           | (inline — `.live-chip` class)     | pulsing red live indicator                                    |
| Brand mark           | `components/shared.jsx`           | `size` (diamond with brand→turf gradient)                     |

## Assets

No image assets — everything is inline SVG or CSS. The Ico object in
`shared.jsx` contains all icons as inline-stroked SVGs (1.5–2.2px stroke,
24px viewBox). Replace with your codebase's icon library (Lucide, Heroicons,
or whatever is established) — the visual vocabulary is "thin stroke,
rounded linecap/linejoin, no fills".

Fonts:
- **Fraunces** (display) — load from Google Fonts. Weights needed: 600 italic,
  700, 800, 900.
- **Inter** — already in your stack.
- **Roboto Mono** — load from Google Fonts. Weights needed: 500, 600, 700.

## Implementation Order

Recommended rollout order, each step ships independently:

1. **Tokens + typography** — merge `app.css` tokens into `tailwind.config.ts` +
   global CSS. Load Fraunces + Roboto Mono. Add `data-theme` / `data-density`
   / `data-motion` wiring on `<html>`.
2. **Sidebar + Topbar** — visible on every authenticated page; immediately
   sets the new brand tone.
3. **Live Game** — the hero. Port the scoring state machine to your real
   API. Most impact, most coach-facing value.
4. **Dashboard** — uses all the primitives; validates the system.
5. **Messages** — two-pane pattern; extract the bubble primitive.
6. **Roster** — straightforward table; introduces new badge tones.
7. **Stats** — SprayChart needs real aggregation pipeline.
8. **Practices** — timeline + RSVP grid.
9. **Schedule** — simplest; easy win to close out.
10. **Marketing landing** — update `apps/marketing` (or wherever the
    public site lives) after the app is on the new system.

## Files

The `prototype/` directory contains the full working prototype:

```
prototype/
  DiamondOS Revamp.html       — Entry point. Wires tokens, components, routing, tweaks.
  styles/
    tokens.css                — Unchanged base DiamondOS tokens (from design system).
    app.css                   — NEW tokens, themes, density, motion, components CSS.
  components/
    shared.jsx                — Icons, BrandMark, Sidebar, Topbar, DiamondField,
                                CountDots, TweaksPanel.
    live_game.jsx             — LiveGamePage (hero screen) + PitchBtn + StrikeZoneHeatmap.
    pages.jsx                 — Dashboard, Roster, Messages, Practices, Stats, Schedule,
                                Marketing.
```

Open `DiamondOS Revamp.html` in a browser to see the running prototype. Use the
in-page Tweaks panel (floating bottom-right when activated) to cycle themes,
densities, motion, and visual tones.

## Contact / Questions

If a state transition, layout, or token is ambiguous in the spec, refer back
to the prototype source — every visual decision is expressed there in plain
React + CSS. When the prototype contradicts this README, the **prototype
wins** (it's the executable source of truth).
